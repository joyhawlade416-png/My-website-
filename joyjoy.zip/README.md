QuickDeal Professional v2 - Deployment Notes
============================================
This package is prepared for public hosting (public domain). It includes:
- Nginx reverse proxy + Certbot placeholders
- WordPress (php-fpm) service + MySQL
- Theme, plugins (wholesale, courier), MU plugin, payment placeholders

IMPORTANT ADMIN CREDENTIALS (auto-created on first init):
- Username: joyhowlader
- Email: joyjh..2000@gmail.com
- Password: 25800@joyhowlader

NOTE: Replace the email/password after first login for security.
Steps to deploy (recommended on VPS or cloud host):
1) Upload this package and unzip on the server.
2) Edit nginx/conf.d/quickdeal.conf: replace YOUR_DOMAIN_HERE with your real domain.
3) Start services: docker-compose up -d
4) Obtain SSL cert (example using certbot):
   docker-compose run --rm certbot certonly --webroot --webroot-path=/var/www/certbot \
     -d YOUR_DOMAIN_HERE --email you@domain.com --agree-tos --no-eff-email
   Then restart nginx: docker-compose restart nginx
5) Visit https://YOUR_DOMAIN_HERE to finish WordPress setup (if not auto-installed).
6) In WP Admin: Plugins -> Activate WooCommerce, Dokan, QuickDeal plugins. Configure gateways.
7) In QuickDeal Courier settings: input RedX / Steadfast API keys and set provider.

Additional recommended steps:
- Configure backups (DB dump + wp-content archive) to remote storage.
- Run php -l on PHP files and enable firewall (ufw) rules.
- Replace WordPress salts in wp/wp-config.php with values from https://api.wordpress.org/secret-key/1.1/salt/
- Configure proper SMTP (WP Mail SMTP) for transactional emails.
GA4: you don't have GA4 yet — add your Measurement ID in the theme functions.php or via a plugin.
